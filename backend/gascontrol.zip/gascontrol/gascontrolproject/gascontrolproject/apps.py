from django.apps import AppConfig


class GascontrolprojectConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gascontrolproject'
